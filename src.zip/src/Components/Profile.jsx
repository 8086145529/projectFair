import React from 'react'
import loginimg from '../Assets/loginimg.jpg'
function Profile() {
  return (
    <>
    <div style={{width:'400px'}} className='card container d-flex flex-column mb-5'>
       <div className='d-flex justify-content-between'> 
        <h2>My Profile</h2>
        <button className='btn btn-outline-info'><i class='fa-solid fa-check'></i></button>
        </div>
        {/* To make an image uploaded from the file use label tag and inside it use input and img tags */}
        <label className='text-center '>
            <input style={{display:'none'}} type="file" />
            <img width={'200px'} height={'200px'} className='rounded-circle' src={loginimg} alt="" />
        </label>
        <div className='d-flex flex-column'>
            <input  className='form-control mt-4 ' type="text" placeholder='Github'/>
            <input className='form-control mt-4 mb-4' type="text" placeholder='LinkedIn'/>
        </div>
    </div>

        
    </>
  )
}

export default Profile