import React, { useState } from 'react'
import { Button, Modal, Row } from 'react-bootstrap';
import imgplaceholder from '../Assets/360_F_248426448_NVKLywWqArG2ADUxDq6QprtIzsF82dMF.jpg'
function AddProject() {
    const [show, setShow] = useState(false);

    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
  return (
    <div>
     <Button variant="success" onClick={handleShow}>
        Add Project
      </Button>

      <Modal
        show={show}
        onHide={handleClose}
        backdrop="static"
        keyboard={false}
        size='lg'
      >
        <Modal.Header closeButton>
          <Modal.Title>Project Details</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <div className='row'>
          <div className='col-lg-6'>
             <label>
                <input style={{display:'none'}} type="file" />
                 <img className='img-fluid'height={'200px'} src={imgplaceholder}alt="" />
             </label>
           </div>
           <div className=' col-lg-6'>
              <div className='mb-3'>
                   <input type="text" className='form-control' placeholder='Project Title' />
              </div>
              <div className='mb-3'>
                   <input type="text" className='form-control' placeholder='Github Link' />
              </div>
              <div className='mb-3'>
                   <input type="text" className='form-control' placeholder='Website Link' />
              </div>
              <div className='mb-3'>
                   <input type="text" className='form-control' placeholder='Project Overview' />
              </div>
            </div>
          </div>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          <Button variant="primary">Understood</Button>
        </Modal.Footer>
      </Modal>
    </div>
  )
}

export default AddProject