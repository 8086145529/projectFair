import React from 'react'
import { Link } from 'react-router-dom'
import loginimg from '../Assets/access-control-system-abstract-concept_335657-3180.avif'
import { Form } from 'react-bootstrap'

function Auth({ register }) {
  const isRegisterForm = register ? true : false // means registerinte value true or false aakam.ith vech nammal jsxil registerinte value true aanenkil chilath display cheyukka enn kodukkum.ee registerinte value true aavunnath,user /register path select cheyumbol aan.aa path alla select cheythath enkil register false aayirikum.
  return (
    <div style={{ width: '100%', height: '100vh' }} className='d-flex justify-content-center align-items-center'>
      <div className='container w-75'>
        {/* Link is an inline element that takes the space only it wanted and when it combines a div with bg-success,both of them placed in a line.so when this two is placed inside a div with width 75%,the div takes another line */}
        <Link to={'/'} style={{ textDecoration: 'none', color: 'blue' }}><i class="fa-solid fa-arrow-left"></i>Back to Home</Link>
        <div style={{height:'600px'}} className='card shadow p-5 bg-success'>
          <div className='row align-items-center'>
            <div className="col-lg-6">
              <img  style={{height:'500px'}} src={loginimg} alt="" />
            </div>
            <div className="col-lg-6">
              <div className='d-flex align-items-center flex-column'>
                <h1 className='fw-bolder text-light mt-2'><i class='fa-brands fa-stack-overflow fa-bounce'></i>Project Fair</h1>
                {/* <h5> inte ullil isRegisterForm true aanenkil 'Sign up to your Account' display cheyuka (indicates Register Form), false annenkil 'Sign In to your Account' display cheyuka (indicates Login form*/}
                <h5 className='fw-bolder text-light mt-2 pb-3'>
                  {
                    isRegisterForm ? 'Sign up to your Account' : 'Sign In to your Account'
                  }
                </h5>
                <Form className='text-light w-100'>
                  {/* Form taginte ullil athyam vendath Usernameinte box aan.but ath registerformil mathram mathi.so isRegisterForm true aanenkil,Form.Group display cheyan parayuka. if condition mathram koduthal mathi else venda. athukond nammal && kodukkunnnu.  */}
                  {
                    isRegisterForm &&
                    <Form.Group className="mb-3" controlId="formBasicName">
                      <Form.Control type="text" placeholder="Username" />
                    </Form.Group>
                  }
                  <Form.Group className="mb-3" controlId="formBasicEmail">
                    <Form.Control type="email" placeholder="Enter Email ID" />
                  </Form.Group>
                  <Form.Group className="mb-3" controlId="formBasicpswd">
                    <Form.Control type="password" placeholder="Enter Password" />
                  </Form.Group>
                  {
                    isRegisterForm?
                    <div>
                      <button className='btn btn-light mb-3'> Register </button>
                      <p>Already have an Account?Click here to <Link style={{color:'black'}} to={'/login'}>Login</Link></p>
                    </div>:
                  <div>
                    <button className='btn btn-light mb-2'>Login </button>
                    <p>New User?Click here to <Link style={{color:'black'}} to={'/register'}>Register</Link></p>
                  </div>

                            }


                </Form>
              </div>
            </div>

          </div>

        </div>
      </div>

    </div>
  )
}

export default Auth